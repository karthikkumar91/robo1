import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/combineLatest';
import 'rxjs/add/operator/withLatestFrom';

interface IMessage {
  id: string;
  text: string;
}

interface IChannelsMessages {
  [ channel: string ]: IMessage[];
}

@Component({
  selector: 'chat',
  template: `
    <div>
      Chat
      <button (click)="setChanel('first')">channel 1</button>
      <button (click)="setChanel('second')">channel 2</button>
      <br>
      channel: {{ currentChannel$ | async}}
      <br>
      <input [value]="text" (input)="text = $event.target.value" /> <button (click)="send()">send</button>
      <div *ngFor="let message of (currentMessages$ | async)">
        {{ message.id }}: {{ message.text }}
      </div>
    </div>
  `
})
export class ChatComponent  {
  public text = "";

  public currentChannel$: Observable<string>;
  public currentMessages$: Observable<IMessage[]>;

  private channel$ = new BehaviorSubject<string>('first');
  private messages$ = new Subject<IMessage>();

  public ngOnInit() {
    const channel$ = this.channel$
      .distinctUntilChanged();

    this.currentChannel$ = channel$;

    this.currentMessages$ = this.messages$
      .withLatestFrom(channel$)
      .scan(
        (channelsMessages, [ message, channel ]) => this.addChannelMessage(channelsMessages, message, channel),
        {} as IChannelsMessages
      )
      .do(() => console.log('>>> new message'))
      .startWith<IChannelsMessages>({})
      .combineLatest(
        channel$,
        (channelsMessages, channel) => channelsMessages[channel] || [],
      );
  }

  public send(): void {
    const message: IMessage = {
      id: Date.now().toString(),
      text: this.text,
    }

    this.messages$.next(message);

    this.text = "";
  }

  public setChanel(channel: string): void {
    this.channel$.next(channel);
  }

  private addChannelMessage(channelsMessages: IChannelsMessages, message: IMessage, channel: string): IChannelsMessages {
    return {
      ...channelsMessages,
      [ channel ]: [
        ...(channelsMessages[channel] || []),
        message,
      ],
    };
  }
}
