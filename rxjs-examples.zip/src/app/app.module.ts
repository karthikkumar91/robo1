import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import 'rxjs/add/operator/do';

import { AppComponent } from './app.component';
import { ChatComponent } from './chat';
import { SearchComponent } from './search';
import { QueueComponent } from './queue';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpClientModule ],
  declarations: [ AppComponent, SearchComponent, QueueComponent, ChatComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
