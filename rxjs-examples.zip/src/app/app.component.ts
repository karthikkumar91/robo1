import { Component } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular 5';

  public searchWords$: Observable<string[]>;

  private data = [
    'aa',
    'ab',
    'abc',
    'bb',
    'bc',
    'bcd',
    'cc',
    'cd',
    'cde',
  ];

  private search$ = new Subject<string>();

  public ngOnInit() {
    this.searchWords$ = this.search$
      .debounceTime(300)
      .distinctUntilChanged()
      .switchMap(text => text
        ? this.loadWords(text)
        : Observable.of([]))
      .catch(() => Observable.of([]));
  }

  public search(text: string): void {
    this.search$.next(text);
  }

  private loadWords(text: string): Promise<string[]> {
    console.log(`>>> loading words for "${text}"`);

    return new Promise(resolve => {
      window.setTimeout(() => {
        const words = this.data.filter(word => word.startsWith(text));
        resolve(words);
      }, 500);
    });
  }
}
