import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/range';
import 'rxjs/add/observable/timer';
import 'rxjs/add/operator/concatMap';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/scan';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/zip';

@Component({
  selector: 'queue',
  template: `
    <div>
      Queue
      <button (click)="tick()">tick</button>
      <button (click)="reset()">reset</button>
      <div *ngIf="counter$ | async; let counter">
        {{ counter[0] }}: {{ counter[1] }}
      </div>
    </div>
  `
})
export class QueueComponent  {
  public counter$: Observable<[ number, number]>;

  private step = 1;

  private reset$ = new Subject<void>();
  private queue$ = new Subject<void>();

  public ngOnInit() {
    this.counter$ = this.reset$
      .startWith(null)
      .switchMap(() => 
        this.queue$
          .scan(step => (step + 1), 0)
          .concatMap(step => this.countingRange(step))
          .startWith(null)
      );
  }

  public reset(): void {
    this.reset$.next();
  }

  public tick(): void {
    this.queue$.next();
  }

  private countingRange(step: number) {
    return Observable.range(1, 10)
      .zip(Observable.timer(300, 300), x => x)
      .map<number, [ number, number ]>(value => ([ step, value ]));
  }
}
